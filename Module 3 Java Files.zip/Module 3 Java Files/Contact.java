package ContactService;

public class Contact {
	private String id;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	//Constructor to hold contact data
	public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
		if ((id == null) || (id.length()>10)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if ((firstName == null) || (firstName.length()>10)) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if ((lastName == null) || (lastName.length()>10)) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if ((phoneNumber == null) || (phoneNumber.length() != 10)) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		if ((address == null) || (address.length()>30)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		for (int i=0; i<10; i++) {
			if((phoneNumber.charAt(i)<'0')||(phoneNumber.charAt(i)>'9')){
				throw new IllegalArgumentException("Invalid Phone Number");
			}
		}
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	
	//Accessors to return contact data
	public String getId() {
		return id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getAddress() {
		return address;
	}
	
	//Mutators to change contact info
	public void setFirstName(String firstName) {
		if ((firstName == null) || (firstName.length()>10)) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if ((lastName == null) || (lastName.length()>10)) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = lastName;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		if ((phoneNumber == null) || (phoneNumber.length() != 10)) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		for (int i=0; i<10; i++) {
			if((phoneNumber.charAt(i)<'0')||(phoneNumber.charAt(i)>'9')){
				throw new IllegalArgumentException("Invalid Phone Number");
			}
		}
		this.phoneNumber = phoneNumber;
	}
	
	public void setAddress(String address) {
		if ((address == null) || (address.length()>30)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		this.address = address;
	}
}
