package ContactServiceTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ContactService.Contact;
import ContactService.ContactService;
import java.util.ArrayList;


class ContactServiceTest {

	@Test
	void testAddContact() {
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		ArrayList<Contact> contacts = ContactService.addContact(contact);
		assertTrue(contacts.size() == 2);
	}
	
	@Test
	void testRemoveContact() {
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		Contact contact2 = new Contact("1234567899", "test1","test2","0123456789","test3");
		ArrayList<Contact> contacts = ContactService.addContact(contact);
		ContactService.addContact(contact2);
		ContactService.removeContact("1234567890");
		assertTrue(contacts.size() == 1);
		assertTrue(contacts.get(0).getId() == "1234567899");
	}


	@Test
	void testUpdateFirstName() {
		ArrayList<Contact> contacts = ContactService.updateFirstName("1234567899", "Change1");
		assertTrue(contacts.get(0).getFirstName() == "Change1");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.updateFirstName("1234567899", null);
			ContactService.updateFirstName("1234567899", "thisshouldnotwork");
		});
	}
}