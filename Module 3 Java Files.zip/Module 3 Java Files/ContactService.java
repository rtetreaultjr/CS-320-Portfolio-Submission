package ContactService;

//Importing arraylist to store contacts and iterator for list iteration
import java.util.ArrayList;

public class ContactService {
	
	public static ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	public static ArrayList<Contact> removeContact(String id) {
		if (contacts == null) {
			throw new IllegalArgumentException("List is empty");
		}
		else{
			for(int i = 0; i<contacts.size(); i++) {
				if(contacts.get(i).getId().equals(id)) {
					contacts.remove(i);
				}
			}
		}
		return contacts;
	}
	
	public static ArrayList<Contact> addContact(Contact contact) {	
		if (contacts == null) {
			contacts.add(contact);
		}
		else {
			for(int i = 0; i<contacts.size(); i++) {
				if (contact.getId().equals(contacts.get(i).getId())) {
					throw new IllegalArgumentException("ID taken");
				}
			}
			contacts.add(contact);
		}
		return contacts;
	}
	
	public static ArrayList<Contact> updateFirstName(String id, String firstName) {
		if (contacts == null) {
			throw new IllegalArgumentException("List is empty");
		}
		else{
			for(int i = 0; i<contacts.size(); i++) {
				if(contacts.get(i).getId().equals(id)) {
					contacts.get(i).setFirstName(firstName);;
				}
			}
		}
		return contacts;
	}
	
	public static ArrayList<Contact> updateLastName(String id, String lastName) {
		if (contacts == null) {
			throw new IllegalArgumentException("List is empty");
		}
		else{
			for(int i = 0; i<contacts.size(); i++) {
				if(contacts.get(i).getId().equals(id)) {
					contacts.get(i).setLastName(lastName);;
				}
			}
		}
		return contacts;
	}
	
	public static ArrayList<Contact> updatePhoneNumber(String id, String phoneNumber) {
		if (contacts == null) {
			throw new IllegalArgumentException("List is empty");
		}
		else{
			for(int i = 0; i<contacts.size(); i++) {
				if(contacts.get(i).getId().equals(id)) {
					contacts.get(i).setPhoneNumber(phoneNumber);;
				}
			}
		}
		return contacts;
	}
	
	public static ArrayList<Contact> updateAddress(String id, String address) {
		if (contacts == null) {
			throw new IllegalArgumentException("List is empty");
		}
		else{
			for(int i = 0; i<contacts.size(); i++) {
				if(contacts.get(i).getId().equals(id)) {
					contacts.get(i).setAddress(address);;
				}
			}
		}
		return contacts;
	}
}
