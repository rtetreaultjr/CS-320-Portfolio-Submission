package ContactServiceTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ContactService.Contact;

class ContactTest {
//Test to ensure contact object stores correct data
	@Test
	void testContact() {
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		assertTrue(contact.getId().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("test1"));
		assertTrue(contact.getLastName().equals("test2"));
		assertTrue(contact.getPhoneNumber().equals("0123456789"));
		assertTrue(contact.getAddress().equals("test3"));
	}
/*
 *Test to ensure contact throws an exception if the 
 *phone number is too long, too short, is null, or
 *contains something other than a digit. Also tests
 *the setPhoneNumber method with the same parameters
 */

	@Test
	void phoneNumberTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "test1","test2","00123456789","test3");
			new Contact("1234567890", "test1","test2","012345678","test3");
			new Contact("1234567890", "test1","test2","012345678a","test3");
			new Contact("1234567890", "test1","test2",null,"test3");
		});
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhoneNumber("01234567890");
			contact.setPhoneNumber(null);
			contact.setPhoneNumber("012345678");
			contact.setPhoneNumber("012345678a");
		});
	}
/*
 *Test to ensure that contact throws an exception
 *if the first name is too long or null.
 *Also tests setFirstName method with the same parameters.	
 */
	@Test
	void firstNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", null,"test2","0123456789","test3");
			new Contact("1234567890", "thisshouldnotwork","test2","0123456789","test3");
		});
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null);
			contact.setFirstName("thisshouldnotwork");
		});
	}
/*
*Test to ensure that contact throws an exception
*if the last name is too long or null.
*Also tests setLastName method with the same parameters.	
*/	
	@Test
	void lastNameTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "test1",null,"0123456789","test3");
			new Contact("1234567890", "test1","thisshouldnotwork","0123456789","test3");
		});
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null);
			contact.setLastName("thisshouldnotwork");
		});
	}
/*
*Test to ensure that contact throws an exception
*if the address is too long or null.
*Also tests setAddress method with the same parameters.	
*/	
	@Test
	void addressTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "test1","test2","0123456789", null);
			new Contact("1234567890", "test1","test2","0123456789","Really long string that is supposed to be over 30 characters long to see if an exception is thrown");
		});
		Contact contact = new Contact("1234567890", "test1","test2","0123456789","test3");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null);
			contact.setAddress("Really long string that is supposed to be over 30 characters long to see if an exception is thrown");
		});
	}
}
